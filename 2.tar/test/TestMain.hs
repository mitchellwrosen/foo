module Main where

import Test.Framework (defaultMain, testGroup)
import Data.Graph.ControlFlowGraphTest

main = defaultMain tests

tests = [ testGroup "ControlFlowGraph tests" cfgTests ]
