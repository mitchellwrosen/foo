module Data.Graph.ControlFlowGraphTest ( cfgTests ) where

import Data.Set (Set)
import Test.Framework.Providers.HUnit (testCase)
import Test.HUnit ((@?=))

import qualified Data.Set as S

import Data.Graph.ControlFlowGraph

cfgTests =
    [ testCase "testInto1" testInto1
    , testCase "testInto2" testInto2
    , testCase "testInto3" testInto3
    , testCase "testInto4" testInto4
    , testCase "testInto5" testInto5
    , testCase "testInto6" testInto6
    , testCase "testInto7" testInto7
    , testCase "testInto8" testInto8
    , testCase "testInto9" testInto9
    , testCase "testInto10" testInto10
    , testCase "testInto11" testInto11
    , testCase "testInto12" testInto12
    , testCase "testInto13" testInto13
    ]

testInto1 = (zeroInZeroOut 0 ~> zeroInZeroOut 1) @?= g (n 0) nil nil nil
testInto2 = (zeroInZeroOut 0 ~> zeroInOneOut 1)  @?= g (n 0) nil nil nil
testInto3 = (zeroInZeroOut 0 ~> oneInZeroOut 1)  @?= g (n 0) nil nil nil
testInto4 = (zeroInZeroOut 0 ~> oneInOneOut 1)   @?= g (n 0) nil nil nil

testInto5 = (zeroInOneOut 0 ~> zeroInZeroOut 1) @?= g (n 0) nil nil nil
testInto6 = (zeroInOneOut 0 ~> zeroInOneOut 1)  @?= g (n 0) nil nil nil
testInto7 = (zeroInOneOut 0 ~> oneInZeroOut 1)  @?= g (ns [0,1]) (e 0 1) nil nil
testInto8 = (zeroInOneOut 0 ~> oneInOneOut 1)   @?= g (ns [0,1]) (e 0 1) nil (o 1)

testInto9 = (oneInZeroOut 0 ~> zeroInZeroOut 1) @?= g (n 0) nil (n 0) nil
testInto10 = (oneInZeroOut 0 ~> zeroInOneOut 1) @?= g (n 0) nil (n 0) nil
testInto11 = (oneInZeroOut 0 ~> oneInZeroOut 1) @?= g (n 0) nil (n 0) nil
testInto12 = (oneInZeroOut 0 ~> oneInOneOut 1)  @?= g (n 0) nil (n 0) nil

testInto13 = (oneInOneOut 0 ~> zeroInZeroOut 1) @?= g (n 0) nil (n 0) nil
testInto14 = (oneInOneOut 0 ~> zeroInOneOut 1)  @?= g (n 0) nil (n 0) (o 0)
testInto15 = (oneInOneOut 0 ~> oneInZeroOut 1)  @?= g (ns [0,1]) (e 0 1) (n 0) nil
testInto16 = (oneInOneOut 0 ~> oneInOneOut 1)   @?= g (ns [0,1]) (e 0 1) (n 0) (o 1)

g = ControlFlowGraph
nil = S.empty

-- | Create a singleton set of a node with the specified id.
n :: Int -> Set Node
n = S.singleton . flip Node ""

-- | Create a set of nodes with the specified ids.
ns :: [Int] -> Set Node
ns = S.fromList . map (\n -> Node n "")

-- | Create a singleton set of an edge between the specified nodes.
e :: Int -> Int -> Set Edge
e from to = S.singleton (Edge from to Nothing)

-- | Create a singleton set of an unlabeled output node from the specified id.
o :: Int -> Set (Node, Maybe String)
o = S.singleton . (\n -> (Node n "", Nothing))

-- | Create a set of unlabeled output nodes from the specified ids.
os :: [Int] -> Set (Node, Maybe String)
os = S.fromList . map (\n -> (Node n "", Nothing))

zeroInZeroOut n = g1 (Node n "") False False
zeroInOneOut  n = g1 (Node n "") False True
oneInZeroOut  n = g1 (Node n "") True  False
oneInOneOut   n = g1 (Node n "") True  True

-- | Create a graph with a single node, possibly with an in and/or an out.
g1 node isIn isOut = ControlFlowGraph
    { _cfgNodes = S.singleton node
    , _cfgEdges = S.empty
    , _cfgIn    = if isIn then S.singleton node else S.empty
    , _cfgOut   = if isOut then S.singleton (node, Nothing) else S.empty
    }
