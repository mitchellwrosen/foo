{-# LANGUAGE LambdaCase #-}

module Main where

import Control.Applicative ((<$>))
import Control.Monad (forM_)
import System.Environment (getArgs, getProgName)

import Data.Graph.CallGraph (CallGraph)
import Data.Graph.ControlFlowGraph (ControlFlowGraph)
import TinyLanguage.ControlFlowGraph
import TinyLanguage.Parser

import qualified Data.Graph.CallGraph        as CG
import qualified Data.Graph.ControlFlowGraph as CFG

-- --all to create an all call graph,
-- --actual to create an actual call graph
-- --cfg to create many control flow graphs
main :: IO ()
main = do
    getArgs >>= \case
        ["--all",    path] -> putStrLn =<< CG.dotGraph <$> allCallGraphFile path
        ["--actual", path] -> putStrLn =<< CG.dotGraph <$> actualCallGraphFile path
        ["--cfg",    path] -> do
            cs <- (fmap . fmap . fmap) CFG.dotGraph $ controlFlowGraphFile path
            forM_ cs $ \(ident, dot_code) -> writeFile ("cfg_" ++ ident ++ ".dot") dot_code
        _ -> printUsage

allCallGraphFile :: FilePath -> IO CallGraph
allCallGraphFile = fmap CG.allCallGraph . parseFile

actualCallGraphFile :: FilePath -> IO CallGraph
actualCallGraphFile = fmap CG.actualCallGraph . parseFile

controlFlowGraphFile :: FilePath -> IO [(Ident, ControlFlowGraph)]
controlFlowGraphFile = fmap graphProgram . parseFile

parseFile :: FilePath -> IO Program
parseFile path = fmap parseProgram (readFile path) >>=
    \case
        Left err   -> error $ show err
        Right prog -> return prog

printUsage :: IO ()
printUsage = do
    prog_name <- getProgName
    putStrLn $ unlines $
        [ "Usage: " ++ prog_name ++ " MODE filepath"
        , ""
        , "MODES"
        , ""
        , "   --all\tPut the DOT code for the all-call graph to stdout."
        , "   --actual\tPut the DOT code for the actual-call graph to stdout."
        , "   --cfg\tCreate one control flow graph DOT file per function."
        , "   --help\tPrint this help text."
        ]
