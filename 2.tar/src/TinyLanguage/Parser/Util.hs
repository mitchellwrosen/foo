module TinyLanguage.Parser.Util where

import Text.Parsec (Parsec, between, digit, spaces, string)
import Control.Applicative (Applicative, (<$), (<$>), (<*), (<*>), many)

import TinyLanguage.Types (Parser)

liftA4 :: Applicative f => (a -> b -> c -> d -> e) -> f a -> f b -> f c -> f d -> f e
liftA4 f a b c d = f <$> a <*> b <*> c <*> d

braces :: Parser a -> Parser a
braces = betweenSym "{" "}"

parens :: Parser a -> Parser a
parens = betweenSym "(" ")"

brackets :: Parser a -> Parser a
brackets = betweenSym "[" "]"

betweenSym :: String -> String -> Parser a -> Parser a
betweenSym open close = between (sym open) (sym close)

int :: Parser Int
int = read <$> many digit <* spaces

true :: Parser Bool
true = True <$ sym "true"

false :: Parser Bool
false = False <$ sym "false"

sym :: String -> Parser String
sym s = string s <* spaces
