module TinyLanguage.ControlFlowGraph where

import Control.Applicative ((<$>))
import Control.Arrow ((&&&))
import Control.Lens
import Control.Monad (ap)
import Control.Monad.State (State, evalState, get, put)

import TinyLanguage.Types
import Data.Graph.ControlFlowGraph

import qualified Data.Set as S

import Debug.Trace

graphProgram :: Program -> [(Ident, ControlFlowGraph)]
graphProgram = map (funcIdent &&& graphFunction)

graphFunction :: Function -> ControlFlowGraph
graphFunction = graphStmt . funcStmt

graphStmt :: Statement -> ControlFlowGraph
graphStmt s = beginGraph ~> evalState (graphStmt' s) firstNodeId ~> endGraph
  where
    graphStmt' :: Statement -> State Int ControlFlowGraph
    graphStmt' (SSeq ss) = mapM graphStmt' ss <&> gconcat
    graphStmt' (SIf e s1 s2) = do
        cond_graph <- newSingleNodeGraph e
        -- Sequence together the condition-graph and the true-graph, and apply the "true" label to the out edges.
        -- Repeat for the false-graph, and finally union the two graphs together.
        fmap union
            (labelOuts "true"  cond_graph ~.> graphStmt' s1) `ap`
            (labelOuts "false" cond_graph ~.> graphStmt' s2)
    graphStmt' (SWhile e s) = do
        cond_graph <- newSingleNodeGraph e
        -- The body's outs are sequenced with the loop condition's ins.
        body_graph <- graphStmt' s .~> cond_graph
        -- Sequence the condition and the body with a "true", and then mark the entire result's outs as "false".
        return $ labelOuts "false" (labelOuts "true" cond_graph ~> body_graph)
    graphStmt' s@(SReturn _) = newSingleNodeGraph s .~> endGraph
    -- SAssign and SPrint are the same.
    graphStmt' s = newSingleNodeGraph s

-- | Create a new ControlFlowGraph consisting of a single Node with the specified label.
newSingleNodeGraph :: Show a => a -> State Int ControlFlowGraph
newSingleNodeGraph = fmap singleNodeGraph . newNode . show

-- | Create a new Node with the specified label, inside a stateful computation. The Node is created with the next-lowest
-- id and the id is incremented.
newNode :: String -> State Int Node
newNode s = do
    i <- get
    put (i+1)
    return $ Node i s
