module TinyLanguage.Types
    ( BinOp(..)
    , Expression(..)
    , Function(..)
    , Ident
    , Parser
    , Program
    , Statement(..)
    , identToFunc
    , mainFunc
    ) where

import Data.List (intercalate)
import Text.Parsec (Parsec)

type Parser = Parsec String ()

type Ident = String

type Program = [Function]

data Function = Function
    { funcIdent  :: Ident
    , funcParams :: [Ident]
    , funcLocals :: [Ident]
    , funcStmt   :: Statement
    } deriving Show

data Statement = SSeq [Statement]
               | SAssign Ident Expression
               | SIf Expression Statement Statement
               | SWhile Expression Statement
               | SReturn Expression
               | SPrint Expression

instance Show Statement where
    show (SSeq ss)     = "{ seq " ++ concatMap show ss ++ " }"
    show (SAssign i e) = "{ assign " ++ i      ++ " " ++ show e  ++ " }"
    show (SIf e s1 s2) = "{ if "     ++ show e ++ " " ++ show s1 ++ " " ++ show s2 ++ " }"
    show (SWhile e s)  = "{ while "  ++ show e ++ " " ++ show s  ++ " }"
    show (SReturn e)   = "{ return " ++ show e ++ " }"
    show (SPrint e)    = "{ print "  ++ show e ++ " }"

data Expression = ENum Int
                | EVar Ident
                | EBool Bool
                | EBinOp BinOp Expression Expression
                | ENot Expression
                | ECall Ident [Expression]

instance Show Expression where
    show (ENum n) = "( num " ++ show n ++ " )"
    show (EVar i) = "( var " ++ i      ++ " )"
    show (EBool True) = "( bool true )"
    show (EBool False) = "( bool false )"
    show (EBinOp b e1 e2) = "( " ++ show b ++ " " ++ show e1 ++ " " ++ show e2 ++ " )"
    show (ENot e) = "( ! " ++ show e ++ " )"
    show (ECall i es) = "( call " ++ i ++ (unwords . map show) es ++ " )"

data BinOp = BEq
           | BNe
           | BLt
           | BGt
           | BLe
           | BGe
           | BPlus
           | BMinus
           | BMult
           | BDiv
           | BAnd
           | BOr

instance Show BinOp where
    show BEq    = "=="
    show BNe    = "!="
    show BLt    = "<"
    show BGt    = ">"
    show BLe    = "<="
    show BGe    = ">="
    show BPlus  = "+"
    show BMinus = "-"
    show BMult  = "*"
    show BDiv   = "/"
    show BAnd   = "and"
    show BOr    = "or"

mainFunc :: Program -> Maybe Function
mainFunc = (`identToFunc` "main")

identToFunc :: Program -> Ident -> Maybe Function
identToFunc [] _ = Nothing
identToFunc (f:fs) ident = if funcIdent f == ident then Just f else identToFunc fs ident
