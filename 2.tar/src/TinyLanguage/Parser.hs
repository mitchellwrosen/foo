{-# LANGUAGE OverloadedStrings #-}

module TinyLanguage.Parser
    ( Parser
    , Ident
    , Program
    , Function(..)
    , Statement(..)
    , Expression(..)
    , BinOp(..)
    , parseProgram
    ) where

import Control.Applicative ((<$), (<*), (*>), liftA, liftA2, liftA3, pure)
import Text.Parsec
import Text.Parsec.Prim

import TinyLanguage.Parser.Util
import TinyLanguage.Types

parseProgram :: String -> Either ParseError Program
parseProgram = parse program ""

program :: Parser Program
program = many function <* eof

function :: Parser Function
function = brackets $ liftA4 Function (sym "fun" *> ident) idents idents statement
  where
    idents :: Parser [Ident]
    idents = parens $ many ident

statement :: Parser Statement
statement = braces $ choice [ sseq, sassign, sif, swhile, sreturn, sprint ]
  where
    sseq    = liftA  SSeq    (sym "seq" *> many statement)
    sassign = liftA2 SAssign (sym "assign" *> ident) expression
    sif     = liftA3 SIf     (sym "if" *> expression) statement statement
    swhile  = liftA2 SWhile  (sym "while" *> expression) statement
    sreturn = liftA  SReturn (sym "return" *> expression)
    sprint  = liftA  SPrint  (sym "print" *> expression)

expression :: Parser Expression
expression = parens $ choice [ enum, evar, ebool, try ebinop, enot, ecall ]
  where
    enum   = liftA  ENum   (sym "num" *> int)
    evar   = liftA  EVar   (sym "var" *> ident)
    ebool  = liftA  EBool  (sym "bool" *> (true <|> false))
    ebinop = liftA3 EBinOp binop expression expression
    enot   = liftA  ENot   (sym "!" *> expression)
    ecall  = liftA2 ECall  (sym "call" *> ident) (many expression)

binop :: Parser BinOp
binop = choice [ beq, bne, ble, bge, blt, bgt, bplus, bminus, bmult, bdiv, band, bor]
  where
    beq    = BEq    <$ sym "=="
    bne    = BNe    <$ sym "!="
    ble    = BLe    <$ try (sym "<=") -- might backtrack to '<'
    bge    = BGe    <$ try (sym ">=") -- might backtrack to '>'
    blt    = BLt    <$ sym "<"
    bgt    = BGt    <$ sym ">"
    bplus  = BPlus  <$ sym "+"
    bminus = BMinus <$ sym "-"
    bmult  = BMult  <$ sym "*"
    bdiv   = BDiv   <$ sym "/"
    band   = BAnd   <$ sym "and"
    bor    = BOr    <$ sym "or"

ident :: Parser Ident
ident = liftA2 (:) letter (many alphaNum) <* spaces
