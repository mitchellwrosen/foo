{-# LANGUAGE MultiParamTypeClasses #-}

module Graph where

{-import Control.Applicative-}
{-import Control.Lens-}
{-import Data.Monoid-}

{-class DotNode n where-}
    {-dotNode :: n -> String-}

{-class DotEdge e where-}
    {-dotEdge :: e -> String-}

{-class Graph g where-}
    {-nodes   :: (Traversable t, DotNode n) => g -> t n-}
    {-edges   :: (Traversable t, DotEdge e) => g -> t e-}

{-dotGraph g = unlines $-}
    {-"digraph {" :-}
    {-dotNode <$> (nodes g) ++-}
    {-dotEdge <$> (edges g) ++-}
    {-["}"]-}

