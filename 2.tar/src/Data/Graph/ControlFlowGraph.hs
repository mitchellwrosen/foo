{-# LANGUAGE TemplateHaskell #-}

module Data.Graph.ControlFlowGraph
    ( ControlFlowGraph(..)
    , (~>)
    , (.~>)
    , (~.>)
    , cfgNodes
    , cfgEdges
    , cfgIn
    , cfgOut
    , Edge(..)
    , Node(..)
    , beginGraph
    , dotGraph
    , edge
    , endGraph
    , firstNodeId
    , gconcat
    , labelOuts
    , singleNodeGraph
    , union
    ) where

import Control.Lens
import Data.Monoid (Monoid(..))
import Data.Set (Set)

import qualified Data.Set as S

data Node = Node
    { nodeId    :: Int
    , nodeLabel :: String
    } deriving (Eq, Ord, Show)

data Edge = Edge
    { edgeFrom  :: Int
    , edgeTo    :: Int
    , edgeLabel :: Maybe String
    } deriving (Eq, Ord, Show)

data ControlFlowGraph = ControlFlowGraph
    { _cfgNodes :: Set Node
    , _cfgEdges :: Set Edge
    , _cfgIn    :: Set Node
    , _cfgOut   :: Set (Node, Maybe String) -- Out-nodes with edge labels to be applied (if sequenced)
    } deriving (Eq, Show)

makeLenses ''ControlFlowGraph

-- | Sequence two graphs together. g1 ~> g2 links each out node of g1 (if any) to each in node of g2 (if any). Another
-- option for combining graphs is the union function.
(~>) :: ControlFlowGraph -> ControlFlowGraph -> ControlFlowGraph
g1 ~> g2 = if S.null (g1^.cfgOut) || S.null (g2^.cfgIn)
               -- The buck stops here. g1 must be closed off. If it wasn't, consider:
               -- g1 (1 out) <> g2 (0 ins) <> g3 (1 in)
               -- If g1 was left untouched, then g2 essentially "disappears" from g1 <> g2 <> g3, leaving g1 <> g3. This is
               -- obviously incorrect, as g2 has no ins and can't be sequenced into.
               then g1 & cfgOut .~ S.empty
               else ControlFlowGraph
                   { _cfgNodes = (g1^.cfgNodes) `S.union` (g2^.cfgNodes)
                   , _cfgEdges = (g1^.cfgEdges) `S.union` (g2^.cfgEdges) `S.union` edges_between
                   , _cfgIn    = g1^.cfgIn
                   , _cfgOut   = g2^.cfgOut
                   }
                 where
                   edges_between :: Set Edge
                   edges_between = S.fromList
                       [ Edge from to label
                           | (from, label) <- (mapped._1) %~ nodeId $ S.toList $ g1^.cfgOut
                           , to <- map nodeId (S.toList $ g2^.cfgIn)
                       ]

-- | Sequence f and g, where f is in a Functor.
(.~>) :: Functor f => f ControlFlowGraph -> ControlFlowGraph -> f ControlFlowGraph
(.~>) f = (<&>) f . flip (~>)

-- | Sequence f and g, where g is in a Functor.
(~.>) :: Functor f => ControlFlowGraph -> f ControlFlowGraph -> f ControlFlowGraph
(~.>) = fmap . (~>)

-- | Union two graphs together by unioning each of their components.
union :: ControlFlowGraph -> ControlFlowGraph -> ControlFlowGraph
union g1 g2 = ControlFlowGraph
    { _cfgNodes = (g1^.cfgNodes) `S.union` (g2^.cfgNodes)
    , _cfgEdges = (g1^.cfgEdges) `S.union` (g2^.cfgEdges)
    , _cfgIn    = (g1^.cfgIn)    `S.union` (g2^.cfgIn)
    , _cfgOut   = (g1^.cfgOut)   `S.union` (g2^.cfgOut)
    }

gconcat :: [ControlFlowGraph] -> ControlFlowGraph
gconcat [] = emptyGraph
gconcat gs = foldr1 (~>) gs

-- BEGIN and END have magic number ID's. Thus, the rest of the graph should begin with id 2.
beginId, endId, firstNodeId :: Int
beginId     = 0
endId       = 1
firstNodeId = 2

beginNode, endNode :: Node
beginNode = Node beginId "BEGIN"
endNode   = Node endId   "END"

beginGraph :: ControlFlowGraph
beginGraph = ControlFlowGraph
    { _cfgNodes = S.singleton beginNode
    , _cfgEdges = S.empty
    , _cfgIn    = S.empty
    , _cfgOut   = S.singleton (beginNode, Nothing)
    }

endGraph :: ControlFlowGraph
endGraph = ControlFlowGraph
    { _cfgNodes = S.singleton endNode
    , _cfgEdges = S.empty
    , _cfgIn    = S.singleton endNode
    , _cfgOut   = S.empty
    }

emptyGraph :: ControlFlowGraph
emptyGraph = ControlFlowGraph
    { _cfgNodes = S.singleton endNode
    , _cfgEdges = S.empty
    , _cfgIn    = S.singleton endNode
    , _cfgOut   = S.empty
    }

singleNodeGraph :: Node -> ControlFlowGraph
singleNodeGraph node = ControlFlowGraph
    { _cfgNodes = S.singleton node
    , _cfgEdges = S.empty
    , _cfgIn    = S.singleton node
    , _cfgOut   = S.singleton (node, Nothing)
    }

-- | Helper method to construct an Edge between two Nodes (obviates having to grab out the ids yourself).
edge :: Node -> Node -> Maybe String -> Edge
edge n1 n2 = Edge (nodeId n1) (nodeId n2)

-- | Generate DOT code from this graph.
dotGraph :: ControlFlowGraph -> String
dotGraph g = unlines $
    "digraph {" :
    map dotNode (S.toList $ g^.cfgNodes) ++
    map dotEdge (S.toList $ g^.cfgEdges) ++
    ["}"]
  where
    dotNode :: Node -> String
    dotNode n = show (nodeId n) ++ " [label=" ++ show (nodeLabel n) ++ "];"

    dotEdge :: Edge -> String
    dotEdge e = concat
        [ show (edgeFrom e)
        , " -> "
        , show (edgeTo e)
        , maybe "" (\s -> " [label=" ++ s ++ "]") (edgeLabel e)
        , ";"
        ]

-- | Label every output node of the graph.
labelOuts :: String -> ControlFlowGraph -> ControlFlowGraph
labelOuts = (cfgOut %~) . S.map . (_2 .~) . Just
