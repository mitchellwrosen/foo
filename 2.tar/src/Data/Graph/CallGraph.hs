module Data.Graph.CallGraph
    ( CallGraph
    , allCallGraph
    , actualCallGraph
    , dotGraph
    ) where

import Control.Arrow ((***))
import Control.Lens
import Control.Monad (when)
import Control.Monad.State
import Control.Monad.Trans.Reader
import Data.Map (Map)
import Data.Maybe (catMaybes, isNothing)

import qualified Data.Map as M

import TinyLanguage.Types

type CallGraph = Map Ident [Ident]

-- | Temporary helper types for generating DOT code from a CallGraph.
type Node = Ident
type Edge = (Node, [Node])
type IndexedNode = (Int, Node)
type IndexedEdge = (IndexedNode, [IndexedNode])

-- | Get the entire CallGraph of a Program, regardless if a function is actually reachable from main or not.
allCallGraph :: Program -> CallGraph
allCallGraph = foldr f M.empty
  where
    f :: Function -> CallGraph -> CallGraph
    f func = M.insert (funcIdent func) (funcCallees func)

-- | Get the identifiers of the functions the specified function calls.
funcCallees :: Function -> [Ident]
funcCallees = stmtCallees . funcStmt

-- | Get the identifiers of the functions the specified statement calls.
stmtCallees :: Statement -> [Ident]
stmtCallees (SSeq ss)     = concatMap stmtCallees ss
stmtCallees (SAssign _ e) = exprCallees e
stmtCallees (SIf e s1 s2) = exprCallees e ++ stmtCallees s1 ++ stmtCallees s2
stmtCallees (SWhile e s)  = exprCallees e ++ stmtCallees s
stmtCallees (SReturn e)   = exprCallees e
stmtCallees (SPrint e)    = exprCallees e

-- | Get the identifiers of the functions the specified expression calls.
exprCallees :: Expression -> [Ident]
exprCallees (EBinOp _ e1 e2) = exprCallees e1 ++ exprCallees e2
exprCallees (ENot e)         = exprCallees e
exprCallees (ECall ident es) = ident : concatMap exprCallees es
exprCallees _                = []

-- | Get the actual CallGraph of functions that may be called during the Program's run (i.e. functions not reachable
-- from main will not appear).
actualCallGraph :: Program -> CallGraph
actualCallGraph prog = maybe M.empty (funcCallGraph prog) (mainFunc prog)

funcCallGraph :: Program -> Function -> CallGraph
funcCallGraph prog func = execState (runReaderT (funcCallGraph' func) prog) M.empty

funcCallGraph' :: Function -> ReaderT Program (State CallGraph) ()
funcCallGraph' func = do
    prog <- ask
    call_graph <- get

    let ident = funcIdent func

    when (isNothing (M.lookup (funcIdent func) call_graph)) $ do
        let callees_idents = funcCallees func
        let callees_funcs  = map (identToFunc prog) callees_idents
        modify $ M.insert ident callees_idents
        mapM_ funcCallGraph' (catMaybes callees_funcs)

dotGraph :: CallGraph -> String
dotGraph g =
    let
        edges = M.toList g
        nodes = map fst edges
        indexed_nodes = zip [0..] nodes
        indexed_edges = map (indexNode indexed_nodes *** map (indexNode indexed_nodes)) edges
    in
        dotGraph' indexed_nodes indexed_edges
  where
    dotGraph' :: [IndexedNode] -> [IndexedEdge] -> String
    dotGraph' ns es = unlines $
        ["digraph {"] ++ nodeStmts ns ++ edgeStmts es ++ ["}"]

    nodeStmts :: [IndexedNode] -> [String]
    nodeStmts = map (\(i,n) -> "   " ++ show i ++ " [label=" ++ n ++ "];")

    edgeStmts :: [IndexedEdge] -> [String]
    edgeStmts = concatMap (\((i,_),ns) ->
                    map (\(i',_) ->
                        "   " ++ show i ++ " -> " ++ show i' ++ ";") ns)

-- | Look up a Node in a "dictionary" of indexed nodes. For now, allow a pattern-match exhaust failure (no pattern for
-- []), which corresponds to a call to a non-existent function.
indexNode :: [IndexedNode] -> Node -> IndexedNode
indexNode ((i,n):ns) n' = if n == n' then (i,n) else indexNode ns n'
